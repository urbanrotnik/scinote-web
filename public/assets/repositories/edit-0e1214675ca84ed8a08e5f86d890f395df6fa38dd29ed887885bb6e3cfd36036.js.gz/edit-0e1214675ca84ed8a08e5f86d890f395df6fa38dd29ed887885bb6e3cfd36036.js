(function() {
  'use strict';

  $('.delete-repo-option').initializeModal('#delete-repo-modal');
  $('.rename-repo-option').initializeModal('#rename-repo-modal');
  $('.copy-repo-option').initializeModal('#copy-repo-modal');
})();
